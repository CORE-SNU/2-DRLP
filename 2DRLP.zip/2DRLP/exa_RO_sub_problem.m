UB = 0;
sigma = zeros(np*T,1);

for t = 1 : T
    
    bin_sub(1:ng+np+nl_shed) = [ Cg; kron(eye(np),I_T(t,:)) * Cwc; kron(eye(nl_shed),I_T(t,:)) * Cds ];
    
    f_sub = [
        zeros(np,1); 
        kron(I_np,I_T(t,:)) * (w_err_u_vec - w_err_l_vec); 
        reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:)) * (w_err_u_vec - w_err_l_vec) ); 
        - reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:)) * (w_err_u_vec - w_err_l_vec) ); 
        - kron( I_np,I_T(t,:) ) * (w_err_u_vec - w_err_l_vec); 
        kron( I_np,I_T(t,:) ) * (w_err_u_vec - w_err_l_vec); 
        - kron( I_ng,I_T(t,:) ) * xl_RO;
        kron( I_ng,I_T(t,:) ) * xu_RO;
        kron( I_np,I_T(t,:) ) * (w_forecast_vec + w_err_l_vec);
        kron( I_nl_shed,I_T(t,:) ) * d_shed_limit;
        - Fmin - Fl * kron(I_nl,I_T(t,:)) * d + Fp * kron(I_np,I_T(t,:)) * (w_forecast_vec + w_err_l_vec);
        Fmax + Fl * kron(I_nl,I_T(t,:)) * d - Fp * kron(I_np,I_T(t,:)) * (w_forecast_vec + w_err_l_vec);
        kron( ones(1,nl),I_T(t,:) ) * d - kron( ones(1,np),I_T(t,:) ) * (w_forecast_vec + w_err_l_vec);
        - kron( ones(1,nl),I_T(t,:) ) * d + kron( ones(1,np),I_T(t,:) ) * (w_forecast_vec + w_err_l_vec)
        ];

    [sol_sub,fval_sub] = cplexmilp(f_sub,Ain_sub,bin_sub,[],[],[],[],[],lb_sub,ub_sub,ctype_sub);
    
    sigma = sigma + kron(sol_sub(1:np),I_T(:,t));
    
    UB = UB - fval_sub;

end
