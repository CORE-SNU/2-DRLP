clear

for is = 1 : 50

    fname = sprintf('sol_Proposed_%d.mat',is);
    load(fname)
    
    tic
    J_red = J;
    J_red_cri = 100;
    
    prob_new = 1/J * ones(J,1);
    if J > J_red_cri
        J_red = J_red_cri;
        Scen_Red
    else
        prob_ori = 1/J * ones(J,1);
        prob_new = prob_ori;
        w_err_data_vec_stack_all_red = 0;
        for j = 1 : J_red
            w_err_data_vec_stack_all_red = [w_err_data_vec_stack_all_red; w_err_data_vec{j}];
        end
        w_err_data_vec_stack_all_red(1) = [];
        w_err_data_red = w_err_data;
        w_err_data_vec_red = w_err_data_vec;
    end
    
    common_matrix
    
    J_KL = J_red;
    rho_KL = prob_new;
    eta_KL = chi2inv(0.99, J_KL - 1)/(2*J);
    err_rel_KL_limit = 5e-3;
    w_err_KL_vec = w_err_data_vec_red;

    exa_DRO_master_matrix
    n_KL = 3*ng*T + 2*ng*T + 1 + (ng*T + np*T + nl_shed*T);
    Ain = [
        C0 zeros(size(C0,1),n_KL - 3*ng*T);
        C11 C12 zeros(size(C11,1),n_KL - 5*ng*T);
        zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),1) [ C22 zeros(size(C22,1),np*T + nl_shed*T) ] ;
        zeros(size(C61,1),5*ng*T + 1) [ C61 C62 C63 ];
        ];
    bin = [ c0; c1; c2; c6 + C64 * zeros(np*T,1) ];
    Aeq = [ zeros(size(C81,1),5*ng*T + 1) C81 C82 C83 ];
    beq = c8 + C84 * zeros(np*T,1);
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T,1);
        1;
        zeros(n_KL - 5*ng*T - 1, 1)
        ];
    lb = zeros(n_KL,1);
    ub = [ ones(3*ng*T,1); inf*ones(2*ng*T+1,1); inf*ones(ng*T,1); zeros(np*T,1); d_shed_limit ];
    ctype = [ repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 1 + ng*T + np*T + nl_shed*T) ];

    matrixT = [
        eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T);
        -eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T);
        zeros(np*T,ng*T) eye(np*T) zeros(np*T,nl_shed*T);
        zeros(np*T,ng*T) -eye(np*T) zeros(np*T,nl_shed*T);
        zeros(nl_shed*T,ng*T) zeros(nl_shed*T,np*T) eye(nl_shed*T);
        zeros(nl_shed*T,ng*T) zeros(nl_shed*T,np*T) -eye(nl_shed*T);
        kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T);
        -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T);
        kron(ones(1,ng),I_T) -kron(ones(1,np),I_T) kron(ones(1,nl_shed),I_T);
        -kron(ones(1,ng),I_T) kron(ones(1,np),I_T) -kron(ones(1,nl_shed),I_T);
        ];
    matrixW = [
        -eye(ng*T) zeros(ng*T);
        zeros(ng*T) eye(ng*T);
        zeros( size(matrixT,1)-2*ng*T, 2*ng*T ) ];

    vectorv = zeros(size(matrixT,1),J_KL);

    for j = 1 : J_KL
        vectorv(:,j) = [
            zeros(2*ng*T,1);
            w_forecast_vec + w_err_KL_vec{j};
            zeros(np*T,1);
            d_shed_limit;
            zeros(nl_shed*T,1);
            kron(Fmax,ones(T,1)) - kron(Fp,I_T) * (w_forecast_vec + w_err_KL_vec{j}) + kron(Fl,I_T)*d;
            -kron(Fmin,ones(T,1)) + kron(Fp,I_T) * (w_forecast_vec + w_err_KL_vec{j}) - kron(Fl,I_T)*d;    
            -kron(ones(1,np),I_T)*(w_forecast_vec + w_err_KL_vec{j}) + kron(ones(1,nl),I_T)*d;
            kron(ones(1,np),I_T)*(w_forecast_vec + w_err_KL_vec{j}) - kron(ones(1,nl),I_T)*d;
            ];
    end
    theta_tilde = zeros(J_KL,1);
    theta_tilde_dualtest = theta_tilde;
    lambda_tilde = zeros(size(matrixT,1),J_KL);
    lambda_hat = lambda_tilde;
    iteration_feas_KL = 0;
    iteration_opt_KL = 0;
    err_rel_KL = 1;
    
    while err_rel_KL > err_rel_KL_limit

        [ sol, est_exa_KL ] = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
        uo_KL = sol(1 : ng*T);
        uu_KL = sol(ng*T + 1 : 2*ng*T);
        ud_KL = sol(2*ng*T + 1 : 3*ng*T);
        xu_KL = sol(3*ng*T + 1 : 4*ng*T);
        xl_KL = sol(4*ng*T + 1 : 5*ng*T);
        LB_KL = est_exa_KL;
        xu = xu_KL;
        xl = xl_KL;
        exa_RO_feas_matrix
        exa_RO_feas_problem

        if imbalance < 1e-6

            for j = 1 : J_KL
                [ ~, theta_tilde(j,1), ~, ~, dd ] = cplexlp(Cg_ext, matrixT, vectorv(:,j) - matrixW * [xu_KL; xl_KL]);
            end            
            for j = 1 : J_KL
                [ lambda_tilde(:,j), dum ] = cplexlp(vectorv(:,j)-matrixW*[xu_KL; xl_KL],-matrixT',Cg_ext,[],[],zeros(size(vectorv,1)));
                theta_tilde_dualtest(j,1) = - dum;
            end
            
            dum = @(x) sum( exp( theta_tilde(1:J_KL)/x + log(rho_KL(1:J_KL)) ) );
            fun = @(x)x * log( dum(x) ) +  x * eta_KL;

            x0 = mean(theta_tilde);
            [alpha_KL,fval,exitflag] = fmincon(fun,x0,[],[],[],[],0);
            UB_KL = kron(Cu,ones(T,1))'*uo_KL + ...
                kron(Csu,ones(T,1))'*uu_KL + ...
                kron(Csd,ones(T,1))'*ud_KL + fval;
        
            dum = 0;
            for j = 1 : J_KL
                dum = dum + rho_KL(j) * exp( theta_tilde(j) / alpha_KL );
            end
            for j = 1 : J_KL
                lambda_hat(:,j) = rho_KL(j) * exp( theta_tilde(j) / alpha_KL )/dum * lambda_tilde(:,j);
            end

            Ain = [ 
                Ain; 
                zeros(1,3*ng*T) sum(lambda_hat,2)'*matrixW -1 zeros(1,size(Ain,2) - 5*ng*T - 1)
                ];
            bin = [ 
                bin; 
                trace(lambda_hat' * vectorv)
                ];
            
            iteration_opt_KL = iteration_opt_KL + 1;
            est_KL = LB_KL;
            err_rel_KL = (UB_KL - LB_KL)/LB_KL;
        else
            w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                ];
            bin = [
                bin;
                c2;
                c6 + C64 * (w_forecast_vec + w_err_wc)
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
            n_KL = n_KL + (ng*T + np*T + nl_shed*T);
            iteration_feas_KL = iteration_feas_KL + 1;
        end
    end
    time_KL = toc;
    
    fname = sprintf('sol_K_%d.mat',is);
    save(fname)

end
