clear

fname = sprintf('sol_R.mat');
load(fname)

J_oos = 1e4;

for is = 1 : 50
    
    fval_oos_Proposed = zeros(J_oos,1);
    fval_oos_M = zeros(J_oos,1);
    fval_oos_K = zeros(J_oos,1);
    fval_oos_N = zeros(J_oos,1);
    fval_oos_C = zeros(J_oos,1);
    fval_oos_S = zeros(J_oos,1);
    fval_oos_R = zeros(J_oos,1);
        
    Ain_oos = [
        kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T);
        -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T)
        ];
    Aeq_oos = kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T));

    w_err_oos_data = cell(J_oos,1);
    w_err_oos_data_vec = cell(J_oos,1);

    wind_err_oos_raw = cell(np,1);
    for ip = 1 : np
       [ wind_err_oos_raw{ip,1}, type ] = pearsrnd(err_mean(ip,1),err_std(ip,1),err_skew(ip,1),err_kur(ip,1),J_oos*T,1);       
    end

    for j = 1 : J_oos
        w_err_oos_data{j} = zeros(T,np);
        w_err_oos_data_vec{j} = zeros(np*T,1);
        for t = 1 : T
            for ip = 1 : np
                dum = w_forecast(t,ip) + cap(ip) * wind_err_oos_raw{ip}( (j-1)*T + t );
                if dum > cap(ip)
                    w_err_oos_data{j}(t,ip) = cap(ip) - w_forecast(t,ip);
                else 
                    if dum < 0
                        w_err_oos_data{j}(t,ip) = - w_forecast(t,ip);
                    else
                        w_err_oos_data{j}(t,ip) = cap(ip) * wind_err_oos_raw{ip}( (j-1)*T + t );
                    end
                end
                w_err_oos_data_vec{j}((ip-1)*T + t) = w_err_oos_data{j}(t,ip);
            end
        end

        bin_oos = [
            kron(Fmax,ones(T,1)) - kron(Fp,I_T)*(w_forecast_vec + w_err_oos_data_vec{j}) + kron(Fl,I_T)*d;
            -kron(Fmin,ones(T,1)) + kron(Fp,I_T)*(w_forecast_vec + w_err_oos_data_vec{j}) - kron(Fl,I_T)*d;
            ];
        beq_oos = d_sum - w_forecast_sum - sum(w_err_oos_data{j},2);

        fname = sprintf('sol_Proposed_%d.mat',is);
        load(fname,'uo_AWDR','uu_AWDR','ud_AWDR','xl_AWDR','xu_AWDR')
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_AWDR; zeros(np*T+nl_shed*T,1)],[xu_AWDR; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_Proposed(j,1) = kron(Cu,ones(T,1))'*uo_AWDR + kron(Csu,ones(T,1))'*uu_AWDR + kron(Csd,ones(T,1))'*ud_AWDR + dum;
        
        fname = sprintf('sol_M_%d.mat',is);
        load(fname,'res','uo_mm','uu_mm','ud_mm','xl_mm','xu_mm')
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_mm; zeros(np*T+nl_shed*T,1)],[xu_mm; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_M(j,1) = kron(Cu,ones(T,1))'*uo_mm + kron(Csu,ones(T,1))'*uu_mm + kron(Csd,ones(T,1))'*ud_mm + dum;
        
        fname = sprintf('sol_K_%d.mat',is);
        load(fname,'uo_KL','uu_KL','ud_KL','xl_KL','xu_KL')
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_KL; zeros(np*T+nl_shed*T,1)],[xu_KL; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_K(j,1) = kron(Cu,ones(T,1))'*uo_KL + kron(Csu,ones(T,1))'*uu_KL + kron(Csd,ones(T,1))'*ud_KL + dum;                      
        
        fname = sprintf('sol_N_%d.mat',is);
        load(fname,'uo_DF','uu_DF','ud_DF','xl_DF','xu_DF')
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_DF; zeros(np*T+nl_shed*T,1)],[xu_DF; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_N(j,1) = kron(Cu,ones(T,1))'*uo_DF + kron(Csu,ones(T,1))'*uu_DF + kron(Csd,ones(T,1))'*ud_DF + dum;
        
        fname = sprintf('sol_C_%d.mat',is);
        load(fname,'uo_CDF','uu_CDF','ud_CDF','xl_CDF','xu_CDF')
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_CDF; zeros(np*T+nl_shed*T,1)],[xu_CDF; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_C(j,1) = kron(Cu,ones(T,1))'*uo_CDF + kron(Csu,ones(T,1))'*uu_CDF + kron(Csd,ones(T,1))'*ud_CDF + dum;
        
        fname = sprintf('sol_S_%d.mat',is);
        load(fname,'uo_SP','uu_SP','ud_SP','xl_SP','xu_SP')
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_SP; zeros(np*T+nl_shed*T,1)],[xu_SP; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_S(j,1) = kron(Cu,ones(T,1))'*uo_SP + kron(Csu,ones(T,1))'*uu_SP + kron(Csd,ones(T,1))'*ud_SP + dum;
        
        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_RO; zeros(np*T+nl_shed*T,1)],[xu_RO; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_R(j,1) = kron(Cu,ones(T,1))'*uo_RO + kron(Csu,ones(T,1))'*uu_RO + kron(Csd,ones(T,1))'*ud_RO + dum;
 
    end
    
    fval_oos_Proposed_mean(is,1) = mean(fval_oos_Proposed);
    fval_oos_M_mean(is,1) = mean(fval_oos_M);
    fval_oos_K_mean(is,1) = mean(fval_oos_K);
    fval_oos_N_mean(is,1) = mean(fval_oos_N);
    fval_oos_C_mean(is,1) = mean(fval_oos_C);
    fval_oos_S_mean(is,1) = mean(fval_oos_S);
    fval_oos_R_mean(is,1) = mean(fval_oos_R);
    
end
