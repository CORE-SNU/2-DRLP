clear

J = 20;
J_HO_in = 0.8 * J;
I_J_HO_in = eye(J_HO_in);
J_HO_oos = J - J_HO_in;
I_J_HO_oos = eye(J_HO_oos);

load('6bus.mat')
%load('24bus.mat')

w_forecast = zeros(T,np);
for ip = 1 : np
    w_forecast(:,ip) = cap(ip) * wind_forecast_scaled{ip,1}(1:T);
end
w_forecast_sum = sum(w_forecast,2);
w_forecast_vec = reshape(w_forecast,[],1);

Ain_wind_err_basic = [ eye(np); -eye(np) ];
bin_wind_err_basic = cell(T,1);
for t = 1 : T
    bin_wind_err_basic{t} = [ cap - w_forecast(t,:)'; w_forecast(t,:)' ];
end

w_err_u_vec = kron(cap,ones(T,1)) - w_forecast_vec;
w_err_l_vec = - w_forecast_vec;

for is = 1 : 50
    
    w_err_data = cell(J,1);
    w_err_data_vec = cell(J,1);
    wind_err_raw = cell(np,1);
    for ip = 1 : np
        wind_err_raw{ip,1} = zeros(J*T,1);
       [ wind_err_raw{ip,1}, type ] = pearsrnd(err_mean(ip,1),err_std(ip,1),err_skew(ip,1),err_kur(ip,1),J*T,1);
    end

    w_err_data_vec_stack_ip = cell(np,1);
    w_err_data_vec_stack_all = 0;
    for ip = 1 : np
        w_err_data_vec_stack_ip{ip} = 0;
    end
    for j = 1 : J
        w_err_data{j} = zeros(T,np);
        w_err_data_vec{j} = zeros(np*T,1);
        for t = 1 : T
            for ip = 1 : np
                dum = w_forecast(t,ip) + cap(ip) * wind_err_raw{ip}( (j-1)*T + t );
                if dum > cap(ip)
                w_err_data{j}(t,ip) = cap(ip) - w_forecast(t,ip);
                else 
                    if dum < 0
                        w_err_data{j}(t,ip) = - w_forecast(t,ip);
                    else
                        w_err_data{j}(t,ip) = cap(ip) * wind_err_raw{ip}( (j-1)*T + t );
                    end
                end
                w_err_data_vec{j}((ip-1)*T + t) = w_err_data{j}(t,ip);
                w_err_data_vec_stack_ip{ip} = [w_err_data_vec_stack_ip{ip}; w_err_data{j}(t,ip)];
            end
        end
        w_err_data_vec_stack_all = [w_err_data_vec_stack_all; w_err_data_vec{j}];
    end
    w_err_data_vec_stack_all(1) = [];
    for ip = 1 : np
        w_err_data_vec_stack_ip{ip}(1) = [];
    end
    
    tic
    beta = 100;
    delta = max(1,beta/J_HO_in);
    N_ep = 3;
    epsilon_DRO_track = [1e-3 1e-2 1e-1];
    
    common_matrix

    w_err_data_HO_in = cell(J_HO_in,1);
    w_err_data_vec_HO_in = cell(J_HO_in,1);
    for j = 1 : J_HO_in
        w_err_data_HO_in{j} = zeros(T,np);
        w_err_data_vec_HO_in{j} = zeros(np*T,1);
        for ip = 1 : np
            for t = 1 : T
                w_err_data_HO_in{j}(t,ip) = w_err_data{j}(t,ip);
                w_err_data_vec_HO_in{j}((ip-1)*T + t) = w_err_data_vec{j}((ip-1)*T + t);
            end
        end
    end

    w_err_data_HO_oos = cell(J_HO_oos,1);
    w_err_data_vec_HO_oos = cell(J_HO_oos,1);
    for j = 1 : J_HO_oos
        w_err_data_HO_oos{j} = zeros(T,np);
        w_err_data_vec_HO_oos{j} = zeros(np*T,1);
        for ip = 1 : np
            for t = 1 : T
                w_err_data_HO_oos{j}(t,ip) = w_err_data{J_HO_in + j}(t,ip);
                w_err_data_vec_HO_oos{j}((ip-1)*T + t) = w_err_data_vec{J_HO_in + j}((ip-1)*T + t);
            end
        end
    end

    bin_wind_err_basic_DRO_limited_HO = cell(T,N_ep);
    for t = 1 : T
        for i_ep = 1 : N_ep
            bin_wind_err_basic_DRO_limited_HO{t,i_ep} = bin_wind_err_basic{t};
        end
    end

    for i_ep = 1 : N_ep

        feascheckindex = 0;
        n_aff_DRO_limited = 3*ng*T + 2*ng*T + 2*(ng*T + np*T + nl_shed*T) + 1 + 2*T;
        epsilon = epsilon_DRO_track(i_ep);
        for t = 1 : T
            for ip = 1 : np
                a = I_np(ip,:);
                dum = 0;
                for j = 1 : J_HO_in
                    dum = [ dum; a * w_err_data_HO_in{j}(t,:)' ];
                end
                dum(1) = [];
                dum_sort = sort(dum);
                bin_wind_err_basic_DRO_limited_HO{t,i_ep}(ip) = min( bin_wind_err_basic_DRO_limited_HO{t,i_ep}(ip), dum_sort(end) + delta * J_HO_in * epsilon);
                bin_wind_err_basic_DRO_limited_HO{t,i_ep}(np + ip) = min( bin_wind_err_basic_DRO_limited_HO{t,i_ep}(np + ip), - dum_sort(1) + delta * J_HO_in * epsilon);
            end
        end
        W_err_sum_u_limited = zeros(T,1); 
        W_err_sum_l_limited = zeros(T,1); 
        W_err_sum_hat_limited = zeros(T,1);
        for t = 1 : T
            [~,dum] = cplexlp(-ones(np,1),Ain_wind_err_basic,bin_wind_err_basic_DRO_limited_HO{t,i_ep});
            W_err_sum_u_limited(t) = -dum;
            [~,W_err_sum_l_limited(t)] = cplexlp(ones(np,1),Ain_wind_err_basic,bin_wind_err_basic_DRO_limited_HO{t,i_ep});
        end
        for j = 1 : J_HO_in
            W_err_sum_hat_limited = W_err_sum_hat_limited + sum(w_err_data_HO_in{j},2);
        end
        W_err_hat_p_limited = J_HO_in * W_err_sum_u_limited - W_err_sum_hat_limited;
        W_err_hat_m_limited = J_HO_in * W_err_sum_l_limited - W_err_sum_hat_limited;

        f = [
            kron(Cu,ones(T,1));
            kron(Csu,ones(T,1));
            kron(Csd,ones(T,1));
            zeros(2*ng*T,1);
            kron(Cg,W_err_sum_hat_limited/J_HO_in);
            Cwc .* kron(ones(np,1),W_err_sum_hat_limited)/J_HO_in;
            Cds .* kron(ones(nl_shed,1),W_err_sum_hat_limited)/J_HO_in;
            kron(Cg,ones(T,1));
            Cwc;
            Cds;
            epsilon;
            W_err_hat_p_limited;
            -W_err_hat_m_limited;
            ];    

        Ain = [
            C0 zeros(size(C0,1),n_aff_DRO_limited - 3*ng*T);
            C11 C12 zeros(size(C11,1),n_aff_DRO_limited - 5*ng*T);
            zeros(ng*T,3*ng*T) -eye(ng*T) zeros(ng*T) kron(eye(ng),diag(W_err_sum_u_limited)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,2*T+1);
            zeros(ng*T,3*ng*T) -eye(ng*T) zeros(ng*T) kron(eye(ng),diag(W_err_sum_l_limited)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,2*T+1);
            zeros(ng*T,3*ng*T) zeros(ng*T) eye(ng*T) -kron(eye(ng),diag(W_err_sum_u_limited)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) -eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,2*T+1);
            zeros(ng*T,3*ng*T) zeros(ng*T) eye(ng*T) -kron(eye(ng),diag(W_err_sum_l_limited)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) -eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,2*T+1);
            zeros(np*T,3*ng*T) zeros(np*T,2*ng*T) zeros(np*T,ng*T) -kron(eye(np),diag(W_err_sum_u_limited)) zeros(np*T,nl_shed*T) zeros(np*T,ng*T) -eye(np*T) zeros(np*T,nl_shed*T) zeros(np*T,2*T+1);
            zeros(np*T,3*ng*T) zeros(np*T,2*ng*T) zeros(np*T,ng*T) -kron(eye(np),diag(W_err_sum_l_limited)) zeros(np*T,nl_shed*T) zeros(np*T,ng*T) -eye(np*T) zeros(np*T,nl_shed*T) zeros(np*T,2*T+1);
            zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) -kron(eye(nl_shed),diag(W_err_sum_u_limited)) zeros(nl_shed*T,ng*T+np*T) -eye(nl_shed*T) zeros(nl_shed*T,2*T+1);
            zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) -kron(eye(nl_shed),diag(W_err_sum_l_limited)) zeros(nl_shed*T,ng*T+np*T) -eye(nl_shed*T) zeros(nl_shed*T,2*T+1);
            zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) kron(eye(nl_shed),diag(W_err_sum_u_limited)) zeros(nl_shed*T,ng*T+np*T) eye(nl_shed*T) zeros(nl_shed*T,2*T+1);
            zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) kron(eye(nl_shed),diag(W_err_sum_l_limited)) zeros(nl_shed*T,ng*T+np*T) eye(nl_shed*T) zeros(nl_shed*T,2*T+1);        
            zeros(T,5*ng*T) 1/J_HO_in*kron(Cg',eye(T)) 1/J_HO_in*kron(ones(1,np),I_T)*diag(Cwc) 1/J_HO_in*kron(ones(1,nl_shed),I_T)*diag(Cds) zeros(T,ng*T + np*T + nl_shed*T) -1/J_HO_in*ones(T,1) -eye(T) zeros(T);
            zeros(T,5*ng*T) -1/J_HO_in*kron(Cg',eye(T)) -1/J_HO_in*kron(ones(1,np),I_T)*diag(Cwc) -1/J_HO_in*kron(ones(1,nl_shed),I_T)*diag(Cds) zeros(T,ng*T + np*T + nl_shed*T) -1/J_HO_in*ones(T,1) zeros(T) -eye(T);
            ];
        bin = [
            a0;
            c1;
            zeros(4*ng*T,1);
            zeros(2*np*T,1);
            zeros(2*nl_shed*T,1);
            kron(ones(2,1),d_shed_limit);
            zeros(2*T,1);
            ];
        Aeq = [
            zeros(T,5*ng*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T)) zeros(T,ng*T+np*T+nl_shed*T) zeros(T,2*T+1);
            zeros(T,5*ng*T + ng*T + np*T + nl_shed*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T)) zeros(T,2*T+1)
            ];
        beq = [
            -ones(T,1);
            d_sum - w_forecast_sum
            ];
        lb = [zeros(3*ng*T,1); zeros(2*ng*T,1); -inf*ones(2*(ng*T+np*T+nl_shed*T),1); zeros(2*T+1,1)];
        ub = [ones(3*ng*T,1); inf*ones(2*ng*T + 2*(ng*T+np*T+nl_shed*T),1); inf*ones(2*T+1,1)];
        ctype = [repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 2*(ng*T+np*T+nl_shed*T) + 2*T+1)];

        checkindex = 1;
        while checkindex > 0

            sol = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
            uo_aff_DRO_limited_HO{i_ep} = sol(1 : ng*T);
            uu_aff_DRO_limited_HO{i_ep} = sol(ng*T+1 : 2*ng*T);
            ud_aff_DRO_limited_HO{i_ep} = sol(2*ng*T+1 : 3*ng*T);
            xu_aff_DRO_limited_HO{i_ep} = sol(3*ng*T+1 : 4*ng*T);
            xl_aff_DRO_limited_HO{i_ep} = sol(4*ng*T+1 : 5*ng*T);
            aff_g_1_DRO_limited_HO{i_ep} = sol(5*ng*T+1 : 6*ng*T);
            aff_g_1_res_DRO_limited_HO{i_ep} = reshape(aff_g_1_DRO_limited_HO{i_ep},T,ng)';
            aff_wc_1_DRO_limited_HO{i_ep} = sol(6*ng*T + 1 : 6*ng*T + np*T);
            aff_wc_1_res_DRO_limited_HO{i_ep} = reshape(aff_wc_1_DRO_limited_HO{i_ep},T,np)';
            aff_ds_1_DRO_limited_HO{i_ep} = sol(6*ng*T+np*T+1 : 6*ng*T+np*T+nl_shed*T);
            aff_ds_1_res_DRO_limited_HO{i_ep} = reshape(aff_ds_1_DRO_limited_HO{i_ep},T,nl_shed)';
            aff_g_0_DRO_limited_HO{i_ep} = sol(6*ng*T+np*T+nl_shed*T+1 : 7*ng*T+np*T+nl_shed*T);
            aff_g_0_res_DRO_limited_HO{i_ep} = reshape(aff_g_0_DRO_limited_HO{i_ep},T,ng)';
            aff_wc_0_DRO_limited_HO{i_ep} = sol(7*ng*T+np*T+nl_shed*T+1: 7*ng*T+2*np*T+nl_shed*T);
            aff_wc_0_res_DRO_limited_HO{i_ep} = reshape(aff_wc_0_DRO_limited_HO{i_ep},T,np)';
            aff_ds_0_DRO_limited_HO{i_ep} = sol(7*ng*T+2*np*T+nl_shed*T+1 : 7*ng*T+2*np*T+2*nl_shed*T);    
            aff_ds_0_res_DRO_limited_HO{i_ep} = reshape(aff_ds_0_DRO_limited_HO{i_ep},T,nl_shed)';

            exa_DRO_master_matrix
            exa_RO_feas_matrix
            xu = xu_aff_DRO_limited_HO{i_ep};
            xl = xl_aff_DRO_limited_HO{i_ep};
            exa_RO_feas_problem
            if imbalance < 1e-6
                wcmaxindex = 0;
                for t = 1 : T
                    for ip = 1 : np
                        [w_err_wc,dum] = cplexlp(-aff_wc_1_res_DRO_limited_HO{i_ep}(ip,t)*ones(np,1)+I_np(:,ip),Ain_wind_err_basic,bin_wind_err_basic_DRO_limited_HO{t,i_ep});
                        wcmax = -dum + aff_wc_0_res_DRO_limited_HO{i_ep}(ip,t);
                        if wcmax > w_forecast(t,ip) + 1e-6
                            Ain = [
                                Ain;
                                zeros(1,3*ng*T) zeros(1,2*ng*T) zeros(1,ng*T) sum(w_err_wc)*I_npT((ip-1)*T+t,:) zeros(1,nl_shed*T) zeros(1,ng*T) I_npT((ip-1)*T+t,:) zeros(1,nl_shed*T) zeros(1,1+2*T + feascheckindex*T*(ng+nl_shed+np));
                                ];
                            bin = [
                                bin;
                                w_forecast(t,ip) + w_err_wc(ip)
                                ];
                            wcmaxindex = wcmaxindex + 1;
                        end
                    end
                end
                linecheckindex = 0;
                for t = 1 : T
                    for l = 1 : M
                        f_line = ( Fg(l,:)*aff_g_1_res_DRO_limited_HO{i_ep}(:,t) + Fl_shed(l,:)*aff_ds_1_res_DRO_limited_HO{i_ep}(:,t) - Fp(l,:)*aff_wc_1_res_DRO_limited_HO{i_ep}(:,t) )*ones(np,1) + Fp(l,:)';
                        [w_err_wc,fval] = cplexlp(f_line,Ain_wind_err_basic,bin_wind_err_basic_DRO_limited_HO{t,i_ep});
                        minflow = fval + Fg(l,:)*aff_g_0_res_DRO_limited_HO{i_ep}(:,t) - Fl(l,:)*d_res(:,t) + Fl_shed(l,:)*aff_ds_0_res_DRO_limited_HO{i_ep}(:,t) + Fp(l,:)*(w_forecast(t,:)'-aff_wc_0_res_DRO_limited_HO{i_ep}(:,t));
                        if 1e-6 < Fmin(l) - minflow
                            Ain = [
                                Ain;
                                zeros(1,5*ng*T) -sum(w_err_wc)*kron(Fg(l,:),I_T(t,:)) sum(w_err_wc)*kron(Fp(l,:),I_T(t,:)) -sum(w_err_wc)*kron(Fl_shed(l,:),I_T(t,:)) ...
                                -kron(Fg(l,:),I_T(t,:)) kron(Fp(l,:),I_T(t,:)) -kron(Fl_shed(l,:),I_T(t,:)) zeros(1,1+2*T + feascheckindex*T*(ng + nl_shed + np));
                                ];
                            bin = [
                                bin;
                                -Fmin(l) + Fp(l,:)*(w_err_wc + w_forecast(t,:)') - Fl(l,:)*d_res(:,t);
                                ];
                            linecheckindex = linecheckindex + 1;
                        end
                        [w_err_wc,fval] = cplexlp(-f_line,Ain_wind_err_basic,bin_wind_err_basic_DRO_limited_HO{t,i_ep});
                        maxflow = - fval + Fg(l,:)*aff_g_0_res_DRO_limited_HO{i_ep}(:,t) - Fl(l,:)*d_res(:,t) + Fl_shed(l,:)*aff_ds_0_res_DRO_limited_HO{i_ep}(:,t) + Fp(l,:)*(w_forecast(t,:)'-aff_wc_0_res_DRO_limited_HO{i_ep}(:,t));
                        if maxflow - Fmax(l) > 1e-6
                            Ain = [
                                Ain;
                                zeros(1,5*ng*T) sum(w_err_wc)*kron(Fg(l,:),I_T(t,:)) -sum(w_err_wc)*kron(Fp(l,:),I_T(t,:)) sum(w_err_wc)*kron(Fl_shed(l,:),I_T(t,:)) ...
                                kron(Fg(l,:),I_T(t,:)) -kron(Fp(l,:),I_T(t,:)) kron(Fl_shed(l,:),I_T(t,:)) zeros(1,1+2*T + feascheckindex*T*(ng+nl_shed+np));                        
                                ];
                            bin = [
                                bin;
                                Fmax(l) - Fp(l,:)*(w_err_wc + w_forecast(t,:)') + Fl(l,:)*d_res(:,t);
                                ];
                            linecheckindex = linecheckindex + 1;
                        end
                    end
                end
                checkindex = wcmaxindex + linecheckindex;
            else
                feascheckindex = feascheckindex + 1;
                dum_w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
                Ain = [
                    Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                    zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                    zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                    ];
                bin = [
                    bin;
                    c2;
                    c6 + C64 * (w_forecast_vec + dum_w_err_wc)
                    ];
                Aeq = [
                    Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                    zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                    ];
                beq = [
                    beq;
                    c8 + C84 * (w_forecast_vec + dum_w_err_wc)
                    ];
                f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
                lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
                ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + dum_w_err_wc; d_shed_limit] ];
                ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
                n_aff_DRO_limited = n_aff_DRO_limited + (ng*T + np*T + nl_shed*T);
            end
        end
        time_aff_DRO_limited_HO(i_ep,1) = toc;
    end

    Ain_oos = [
        kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T);
        -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T)
        ];
    for j = 1 : J_HO_oos
        bin_oos = [
            kron(Fmax,ones(T,1)) - kron(Fp,I_T)*(w_forecast_vec + w_err_data_vec_HO_oos{j}) + kron(Fl,I_T)*d;
            -kron(Fmin,ones(T,1)) + kron(Fp,I_T)*(w_forecast_vec + w_err_data_vec_HO_oos{j}) - kron(Fl,I_T)*d;
            ];
        Aeq_oos = kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T));
        beq_oos = d_sum - w_forecast_sum - sum(w_err_data_HO_oos{j},2);
        for i_ep = 1 : N_ep
            [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_aff_DRO_limited_HO{i_ep}; zeros(np*T+nl_shed*T,1)],[xu_aff_DRO_limited_HO{i_ep}; w_forecast_vec + w_err_data_vec_HO_oos{j}; d_shed_limit]);
            fval_oos_aff_DRO_limited_HO(j,i_ep) = ...
                kron(Cu,ones(T,1))'*uo_aff_DRO_limited_HO{i_ep} + ...
                kron(Csu,ones(T,1))'*uu_aff_DRO_limited_HO{i_ep} + ...
                kron(Csd,ones(T,1))'*ud_aff_DRO_limited_HO{i_ep} + dum;
        end
    end
    [~,dum] = sort(sum(fval_oos_aff_DRO_limited_HO));
    epsilon_aff_DRO_limited = epsilon_DRO_track(dum(1));
    i_ep = dum(1);

    uo_AWDR = uo_aff_DRO_limited_HO{i_ep};
    uu_AWDR = uu_aff_DRO_limited_HO{i_ep};
    ud_AWDR = ud_aff_DRO_limited_HO{i_ep};
    xu_AWDR = xu_aff_DRO_limited_HO{i_ep};
    xl_AWDR = xl_aff_DRO_limited_HO{i_ep};
    aff_g_1_AWDR = aff_g_1_DRO_limited_HO{i_ep};
    aff_g_1_AWDR_res = aff_g_1_res_DRO_limited_HO{i_ep};
    aff_wc_1_AWDR = aff_wc_1_DRO_limited_HO{i_ep};
    aff_wc_1_AWDR_res = aff_wc_1_res_DRO_limited_HO{i_ep};
    aff_ds_1_AWDR = aff_ds_1_DRO_limited_HO{i_ep};
    aff_ds_1_AWDR_res = aff_ds_1_res_DRO_limited_HO{i_ep};
    aff_g_0_AWDR = aff_g_0_DRO_limited_HO{i_ep};
    aff_g_0_AWDR_res = aff_g_0_res_DRO_limited_HO{i_ep};
    aff_wc_0_AWDR = aff_wc_0_DRO_limited_HO{i_ep};
    aff_wc_0_AWDR_res = aff_wc_0_res_DRO_limited_HO{i_ep};
    aff_ds_0_AWDR = aff_ds_0_DRO_limited_HO{i_ep};
    aff_ds_0_AWDR_res = aff_ds_0_res_DRO_limited_HO{i_ep};    
    time_AWDR = toc;

    fname = sprintf('sol_Proposed_%d.mat',is);
    save(fname)
    
end
