prob_ori = 1/J * ones(J,1);
j_remaining = [1:J]';
J_remaining = J;
dist_of_scen = cell(J_red,1);
for j = 1 : J_red
    dist_of_scen{j} = zeros(J);
end

for j = 1 : J
    for j_prime = 1 : J
        dist_of_scen{1}(j,j_prime) = norm(w_err_data_vec{j} - w_err_data_vec{j_prime},1);
    end
end

z = zeros(J,1);
for j = 1 : J
    z(j,1) = dist_of_scen{1}(j,:) * 1/J * ones(J,1);
end
[~,z_minimizer] = sort(z);
j_preserve = z_minimizer(1);
J_remaining = J_remaining - 1;
j_remaining(j_preserve(end)) = 0;

for stepindex = 2 : J_red

    dist_of_scen{stepindex} = zeros(J);
    for j = 1 : J
        for j_prime = 1 : J
            if (abs(j_preserve - j) <= 0) + (abs(j_preserve - j_prime) <= 0) == 0
                dist_of_scen{stepindex}(j,j_prime) = min ( dist_of_scen{stepindex-1}(j,j_prime), dist_of_scen{stepindex-1}(j,j_preserve(end)) );
            end
        end
    end    
    for j = 1 : J
        z(j,1) = dist_of_scen{stepindex}(j,:) * 1/J * ones(J,1);
    end
    [~,z_minimizer] = sort(z);
    
    dum = 0;
    j = 0;
    while dum == 0
        j = j + 1;
        if ( abs(j_preserve - z_minimizer(j)) <= 0 ) == 0
            dum = 1;
        end
    end
    j_preserve = [ j_preserve; z_minimizer(j) ];
    J_remaining = J_remaining - 1;   
    j_remaining(z_minimizer(j)) = 0;

end
j_remaining = nonzeros(j_remaining);
prob_new = prob_ori;

dum = sort(j_preserve);
w_err_data_vec_red = cell(J_red,1);
w_err_data_red = cell(J_red,1);
for j = 1 : J_red
    w_err_data_vec_red{j} = w_err_data_vec{dum(j)};
    w_err_data_red{j} = w_err_data{dum(j)};
end

w_err_data_vec_stack_all_red = 0;
for j = 1 : J_red
    w_err_data_vec_stack_all_red = [w_err_data_vec_stack_all_red; w_err_data_vec_red{j}];
end
w_err_data_vec_stack_all_red(1) = [];
        
for j = 1 : size(j_remaining,1)
    prob_new(j_remaining(j)) = 0;    
    [~,dum] = sort(dist_of_scen{1}(j_remaining(j),:));    
    dum2 = 0;
    j_prime = 0;
    while dum2 == 0
        j_prime = j_prime + 1;
        if (dum(j_prime)~=j_remaining(j)) && (sum((abs( j_remaining - dum(j_prime) ) <= 0)) == 0)
            prob_new(dum(j_prime)) = prob_new(dum(j_prime)) + prob_ori(j_remaining(j));
            dum2 = 1;
        end 
    end
end
prob_new = nonzeros(prob_new);
