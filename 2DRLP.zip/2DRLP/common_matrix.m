I_ng = eye(ng);
MU = [ zeros(1,T); -eye(T-2) zeros(T-2,2) ] + [ eye(T-1) zeros(T-1,1) ];
MD = [ zeros(1,T); eye(T-2) zeros(T-2,2) ] + [ -eye(T-1) zeros(T-1,1) ]; 
Ain_mas_MT = zeros(1,3*ng*T); 
bin_mas_MT = 0;
for ig = 1 : ng
    if Tu(ig) > 1
        Mu = u0(ig) * I_T(:,1);
        for tau = 1 : Tu(ig) - 1
            Ain_mas_MT = [
                Ain_mas_MT;
                kron( I_ng(ig,:), MU( 1:T-tau , : ) + [ zeros( T-tau,tau ) -eye(T-tau) ] ) zeros(T-tau, 3*ng*T - ng*T)
                ];
            bin_mas_MT = [
                bin_mas_MT;
                Mu( 1 : T-tau )
                ];    
        end
    end
    if Td(ig) > 1
        Md = -u0(ig) * I_T(:,1) + ones(T,1);
        for tau = 1 : Td(ig) - 1
            Ain_mas_MT = [
                Ain_mas_MT;
                kron( I_ng(ig,:), MD( 1:T-tau , : ) + [ zeros( T-tau,tau ) eye(T-tau) ] ) zeros(T-tau, 3*ng*T - ng*T)
                ];
            bin_mas_MT = [
                bin_mas_MT;
                Md( 1 : T-tau )
                ];
        end
    end
end
Ain_mas_MT = Ain_mas_MT(2:end,:);
bin_mas_MT = bin_mas_MT(2:end);

dum = [ zeros(1,T); eye(T-1) zeros(T-1,1) ];

A0 = [
    kron( eye(ng) , eye(T) - [zeros(1,T); eye(T-1) zeros(T-1,1)] ) -eye(ng*T) zeros(ng*T);
    kron( eye(ng) , -eye(T) + [zeros(1,T); eye(T-1) zeros(T-1,1)] ) zeros(ng*T) -eye(ng*T);
    zeros(ng*T) eye(ng*T) eye(ng*T);
    eye(ng*T) zeros(ng*T) eye(ng*T);
    kron(eye(ng),dum) eye(ng*T) zeros(ng*T);
    Ain_mas_MT
    ];

a0 = [
    kron( u0,I_T(:,1) );
    kron( -u0,I_T(:,1) );
    ones(2*ng*T,1);
    ones(ng*T,1) - kron(u0,I_T(:,1));
    bin_mas_MT
    ];

A11 = [
    kron(diag(Xmin),eye(T)) zeros(ng*T) zeros(ng*T); % xi1
    -kron(diag(Xmax),eye(T)) zeros(ng*T) zeros(ng*T); % xi2
    -kron(diag(Xu),[zeros(1,T); I_T(1:T-1,:)]) -kron(diag(Xsu),eye(T)) zeros(ng*T); %xi 5
    -kron(diag(Xd),eye(T)) zeros(ng*T) -kron(diag(Xsd),eye(T)); % xi6
    ];
A12 = [
    zeros(ng*T) -eye(ng*T);
    eye(ng*T) zeros(ng*T);
    eye(ng*T) kron(eye(ng),-[zeros(1,T); I_T(1:T-1,:)]);
    kron(eye(ng),[zeros(1,T); I_T(1:T-1,:)]) -eye(ng*T);
    ];
a1 = [
    zeros(2*ng*T,1);
    kron(xl0+Xu.*u0,I_T(:,1));
    -kron(xu0,I_T(:,1));
    ];

A2 = [ -eye(ng*T) eye(ng*T) ];
a2 = zeros(ng*T,1);
C0 = A0; 
c0 = a0;

C11 = [ A11; zeros(size(A2,1),3*ng*T) ];
C12 = [ A12; A2 ];
c1 = [ a1; a2 ];
