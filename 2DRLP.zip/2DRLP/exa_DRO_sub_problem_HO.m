UB = 0;
sigma_plus = zeros(np*T,1);
sigma_minus = zeros(np*T,1);
w_err_plus_u_HO = zeros(np*T,1);
w_err_minus_u_HO = zeros(np*T,1);
for ip = 1 : np
    for t = 1 : T
        w_err_plus_u_HO((ip-1)*T+t) = bin_wind_err_basic_DRO_limited_HO{t,i_ep}(ip) - w_err_data_vec_HO_in{j}((ip-1)*T+t);
        w_err_minus_u_HO((ip-1)*T+t) = bin_wind_err_basic_DRO_limited_HO{t,i_ep}(np + ip) + w_err_data_vec_HO_in{j}((ip-1)*T+t);
    end
end

for t = 1 : T
    
    bin_sub(1:ng+np+nl_shed) = [ Cg; kron(eye(np),I_T(t,:)) * Cwc; kron(eye(nl_shed),I_T(t,:)) * Cds ];
    
    f_sub = [
        lambda * kron(I_np,I_T(t,:)) * w_err_plus_u_HO;
        lambda * kron(I_np,I_T(t,:)) * w_err_minus_u_HO;
        kron(I_np,I_T(t,:)) * w_err_plus_u_HO;
        - kron(I_np,I_T(t,:)) * w_err_minus_u_HO;
        reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_plus_u_HO );
        - reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_minus_u_HO );
        - reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_plus_u_HO );
        reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_minus_u_HO );
        - kron( I_np,I_T(t,:) ) * w_err_plus_u_HO;
        kron( I_np,I_T(t,:) ) * w_err_minus_u_HO;
        kron( I_np,I_T(t,:) ) * w_err_plus_u_HO;
        - kron( I_np,I_T(t,:) ) * w_err_minus_u_HO;
        - kron( I_ng,I_T(t,:) ) * xl_exa_DRO_HO{i_ep};
        kron( I_ng,I_T(t,:) ) * xu_exa_DRO_HO{i_ep};
        kron( I_np,I_T(t,:) ) * (w_forecast_vec + w_err_data_vec_HO_in{j});
        kron( I_nl_shed,I_T(t,:) ) * d_shed_limit;
        - Fmin - Fl * kron(I_nl,I_T(t,:)) * d + Fp * kron(I_np,I_T(t,:)) * (w_forecast_vec + w_err_data_vec_HO_in{j});
        Fmax + Fl * kron(I_nl,I_T(t,:)) * d - Fp * kron(I_np,I_T(t,:)) * (w_forecast_vec + w_err_data_vec_HO_in{j});
        kron( ones(1,nl),I_T(t,:) ) * d - kron( ones(1,np),I_T(t,:) ) * (w_forecast_vec + w_err_data_vec_HO_in{j});
        - kron( ones(1,nl),I_T(t,:) ) * d + kron( ones(1,np),I_T(t,:) ) * (w_forecast_vec + w_err_data_vec_HO_in{j});
        ];
    
    [sol_sub,fval_sub] = cplexmilp(f_sub,Ain_sub,bin_sub,[],[],[],[],[],lb_sub,ub_sub,ctype_sub);
    
    sigma_plus = sigma_plus + kron(sol_sub(1:np),I_T(:,t));
    sigma_minus = sigma_minus + kron(sol_sub(np + 1:2*np),I_T(:,t));

    UB = UB - fval_sub;

end
