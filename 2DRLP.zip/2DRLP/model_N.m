clear

for is = 1 : 50

    fname = sprintf('sol_Proposed_%d.mat',is);
    load(fname)

    tic
    J_red = J;
    J_red_cri = 100;

    prob_new = 1/J * ones(J,1);
    if J > J_red_cri
        J_red = J_red_cri;
        Scen_Red
    else
        prob_ori = 1/J * ones(J,1);
        prob_new = prob_ori;
        w_err_data_vec_stack_all_red = 0;
        for j = 1 : J_red
            w_err_data_vec_stack_all_red = [w_err_data_vec_stack_all_red; w_err_data_vec{j}];
        end
        w_err_data_vec_stack_all_red(1) = [];
        w_err_data_red = w_err_data;
        w_err_data_vec_red = w_err_data_vec;
    end

    common_matrix
    
    J_DF = J_red;
    alpha_DF = 0.99;
    beta_DF = log(2*J_DF/(1 - alpha_DF)) * J_DF / (2*J);
    err_rel_DF_limit = 5e-3;
    Ain_Psi_DF = [
        ones(1,J_DF) ones(1,J_DF);
        -eye(2*J_DF);
        eye(J_DF) -eye(J_DF)
        -eye(J_DF) eye(J_DF)
        ];
    Aeq_Psi_DF = [
        ones(1,J_DF) -ones(1,J_DF)
        ];
    pi_DF_zero = prob_new;
    bin_Psi_DF = [
        beta_DF;
        zeros(2*J_DF,1);
        ones(J_DF,1) - pi_DF_zero;
        pi_DF_zero
        ];
    beq_Psi_DF = 0;

    exa_DRO_master_matrix
    n_DF = 3*ng*T + 2*ng*T + 1 + J_DF * (ng*T + np*T + nl_shed*T);
    Ain = [
        C0 zeros(size(C0,1),n_DF - 3*ng*T);
        C11 C12 zeros(size(C11,1),n_DF - 5*ng*T);
        zeros(J_DF * size(C21,1),3*ng*T) kron(ones(J_DF,1),C21) zeros(J_DF * size(C21,1),1) kron(eye(J_DF),[C22 zeros(size(C22,1),np*T + nl_shed*T)]);
        zeros(J_DF * size(C61,1),5*ng*T + 1) kron(eye(J_DF),[ C61 C62 C63 ]);
        zeros(1,5*ng*T) -1 kron(pi_DF_zero',Cg_ext')
        ];
    bin = [
        c0;
        c1;
        kron(ones(J_DF,1),c2);
        zeros(J_DF * size(c6,1),1);
        0
        ];
    beq = zeros(J_DF * size(c8,1),1);
    for j = 1 : J_DF
        bin( size([c0;c1;kron(ones(J_DF,1),c2)],1) + (j-1)*size(c6,1) + 1 : size([c0;c1;kron(ones(J_DF,1),c2)],1) + j * size(c6,1) ) = c6 + C64 * (w_forecast_vec + w_err_data_vec_red{j});
        beq( (j-1) * size(c8,1) + 1 : j * size(c8,1) ) = c8 + C84 * (w_forecast_vec + w_err_data_vec_red{j});
    end
    Aeq = [ zeros(J_DF * size(C81,1),5*ng*T + 1) kron(eye(J_DF),[C81 C82 C83]) ];
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T,1);
        1;
        zeros(n_DF - 5*ng*T - 1, 1)
        ];
    lb = zeros(n_DF,1);
    ub = [ ones(3*ng*T,1); inf*ones(2*ng*T+1,1); kron(ones(J_DF,1),[ inf*ones(ng*T,1); zeros(np*T,1); d_shed_limit ]) ];

    for j = 1 : J_DF
        ub( 5*ng*T + 1 + (j-1)*(ng*T + np*T + nl_shed*T) + ng*T + 1 : 5*ng*T + 1 + (j-1)*(ng*T + np*T + nl_shed*T) + ng*T + np*T ) = w_forecast_vec + w_err_data_vec_red{j};
    end

    ctype = [ repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 1 + J_DF * (ng*T + np*T + nl_shed*T)) ];
    
    err_rel_DF = 1;
    iter_feas_DF = 0;
    while err_rel_DF > err_rel_DF_limit
        [ sol, est_DF, exitflag ] = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
        uo_DF = sol(1 : ng*T);
        uu_DF = sol(ng*T + 1 : 2*ng*T);
        ud_DF = sol(2*ng*T + 1 : 3*ng*T);
        xu_DF = sol(3*ng*T + 1 : 4*ng*T);
        xl_DF = sol(4*ng*T + 1 : 5*ng*T);
        LB_DF = est_DF;
        xu = xu_DF;
        xl = xl_DF;
        exa_RO_feas_matrix
        exa_RO_feas_problem
        if imbalance < 1e-6
            Ain_DF = [
                kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T);
                -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T)
                ];
            Aeq_DF = kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T));
            fval_sub_DF = zeros(J_DF,1);
            for j = 1 : J_DF
                bin_DF = [
                    kron(Fmax,ones(T,1)) - kron(Fp,I_T)*(w_forecast_vec + w_err_data_vec_red{j}) + kron(Fl,I_T)*d;
                    -kron(Fmin,ones(T,1)) + kron(Fp,I_T)*(w_forecast_vec + w_err_data_vec_red{j}) - kron(Fl,I_T)*d;
                    ];
                beq_DF = d_sum - w_forecast_sum - sum(w_err_data_red{j},2);
                [ ~, fval_sub_DF(j,1) ] = cplexlp(Cg_ext,Ain_DF,bin_DF,Aeq_DF,beq_DF,[xl_DF; zeros(np*T+nl_shed*T,1)],[xu_DF; w_forecast_vec + w_err_data_vec_red{j}; d_shed_limit]);
            end
            
            pi_DF = cplexlp(-kron([1; -1],fval_sub_DF),Ain_Psi_DF,bin_Psi_DF,Aeq_Psi_DF,beq_Psi_DF);
            pi_DF_plus = pi_DF(1 : J_DF);
            pi_DF_minus = pi_DF(J_DF + 1 : end);
            pi_DF_worst = pi_DF_zero + pi_DF_plus - pi_DF_minus;
            UB_DF = kron(Cu,ones(T,1))'*uo_DF + kron(Csu,ones(T,1))'*uu_DF + ...
                kron(Csd,ones(T,1))'*ud_DF + pi_DF_worst'*fval_sub_DF;
            err_rel_DF = (UB_DF - LB_DF)/LB_DF;
            if err_rel_DF > err_rel_DF_limit
                Ain = [
                    Ain;
                    zeros(1,5*ng*T) -1 kron(pi_DF_worst',Cg_ext') zeros(1,iter_feas_DF * (ng*T + np*T + nl_shed*T))
                    ];
                bin = [
                    bin;
                    0
                    ];
            end
        else
            w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                ];
            bin = [
                bin;
                c2;
                c6 + C64 * (w_forecast_vec + w_err_wc)
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
            n_DF = n_DF + (ng*T + np*T + nl_shed*T);
            iter_feas_DF = iter_feas_DF + 1;
        end
    end
    time_DF = toc;
    
    fname = sprintf('sol_N_%d.mat',is);
    save(fname)

end
