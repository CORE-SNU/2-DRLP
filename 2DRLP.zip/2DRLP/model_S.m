clear

for is = 1 : 50

    fname = sprintf('sol_Proposed_%d.mat',is);
    load(fname)

    tic
    J_red = J;
    J_red_cri = 100;
    
    prob_new = 1/J * ones(J,1);
    if J > J_red_cri
        J_red = J_red_cri;
        Scen_Red
    else
        prob_ori = 1/J * ones(J,1);
        prob_new = prob_ori;
        w_err_data_vec_stack_all_red = 0;
        for j = 1 : J_red
            w_err_data_vec_stack_all_red = [w_err_data_vec_stack_all_red; w_err_data_vec{j}];
        end
        w_err_data_vec_stack_all_red(1) = [];
        w_err_data_red = w_err_data;
        w_err_data_vec_red = w_err_data_vec;
    end

    common_matrix
    
    n_SP = 3*ng*T + 2*ng*T + J_red*(ng*T + np*T + nl_shed*T);
    Ain = [
        C0 zeros(size(C0,1),n_SP - 3*ng*T);
        C11 C12 zeros(size(C11,1),n_SP - 5*ng*T);
        zeros(ng*J_red*T,3*ng*T) -kron(ones(J_red,1),eye(ng*T)) zeros(ng*T*J_red,ng*T) kron(eye(J_red),kron([eye(ng) zeros(ng,np + nl_shed)],eye(T)));
        zeros(ng*J_red*T,3*ng*T+ng*T) kron(ones(J_red,1),eye(ng*T)) -kron(eye(J_red),kron([eye(ng) zeros(ng,np + nl_shed)],eye(T)));
        zeros(J_red*M*T,5*ng*T) kron(eye(J_red),kron([Fg -Fp Fl_shed],I_T))
        zeros(J_red*M*T,5*ng*T) kron(eye(J_red),kron([-Fg Fp -Fl_shed],I_T))
        ];
    bin = [
        a0;
        c1;
        zeros(2*ng*J_red*T,1);
        kron(ones(J_red,1),kron(Fmax,ones(T,1)) - kron(Fp,I_T)*w_forecast_vec + kron(Fl,I_T)*d) - kron(eye(J_red),kron(Fp,I_T))*w_err_data_vec_stack_all_red;
        kron(ones(J_red,1),-kron(Fmin,ones(T,1)) + kron(Fp,I_T)*w_forecast_vec - kron(Fl,I_T)*d) + kron(eye(J_red),kron(Fp,I_T))*w_err_data_vec_stack_all_red;
        ];
    Aeq = [
        zeros(J_red*T,5*ng*T) kron(eye(J_red),kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T)));
        ];
    beq = [
        kron(ones(J_red,1),d_sum - w_forecast_sum) - kron(eye(J_red),kron(ones(1,np),I_T)) * w_err_data_vec_stack_all_red;
        ];
    lb = [
        zeros(3*ng*T,1); zeros(2*ng*T,1); zeros(J_red*(ng*T+np*T+nl_shed*T),1)
        ];
    ub = [
        ones(3*ng*T,1); inf*ones(2*ng*T,1); kron(ones(J_red,1),[inf*ones(ng*T,1); inf*ones(np*T,1); d_shed_limit])
        ];
    for j = 1 : J_red
        ub( 5*ng*T+ (j-1)*(ng*T + np*T + nl_shed*T) + ng*T + 1 : + 5*ng*T+ (j-1)*(ng*T + np*T + nl_shed*T) + ng*T + np*T ) = w_forecast_vec + w_err_data_vec_red{j};
    end
    ctype = [
        repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + J_red*(ng*T+np*T+nl_shed*T))
        ];
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T,1);
        kron(prob_new,Cg_ext)
        ];
    
    imbalance = 1;
    while imbalance >  1e-6

        sol = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
        uo_SP = sol(1 : ng*T);
        uu_SP = sol(ng*T+1 : 2*ng*T);
        ud_SP = sol(2*ng*T + 1 : 3*ng*T);
        xu_SP = sol(3*ng*T + 1 : 4*ng*T);
        xl_SP = sol(4*ng*T + 1 : 5*ng*T);
        
        exa_DRO_master_matrix
        exa_RO_feas_matrix
        xu = xu_SP;
        xl = xl_SP;
        exa_RO_feas_problem
        if imbalance > 1e-6
            w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                ];
            bin = [
                bin;
                c2;
                c6 + C64 * (w_forecast_vec + w_err_wc)
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
        end
    end
    time_SP = toc;

    fname = sprintf('sol_S_%d.mat',is);
    save(fname)

end
