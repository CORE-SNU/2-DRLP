UB = 0;
sigma_plus = zeros(np*T,1);
sigma_minus = zeros(np*T,1);

w_err_plus_u = zeros(np*T,1);
w_err_minus_u = zeros(np*T,1);
for ip = 1 : np
    for t = 1 : T
        w_err_plus_u((ip-1)*T+t) = bin_wind_err_basic_DRO_limited{t}(ip) - w_err_data_vec{j}((ip-1)*T+t);
        w_err_minus_u((ip-1)*T+t) = bin_wind_err_basic_DRO_limited{t}(np + ip) + w_err_data_vec{j}((ip-1)*T+t);
    end
end

for t = 1 : T
    
    bin_sub(1:ng+np+nl_shed) = [ Cg; kron(eye(np),I_T(t,:)) * Cwc; kron(eye(nl_shed),I_T(t,:)) * Cds ];
    
    f_sub = [
        lambda * kron(I_np,I_T(t,:)) * w_err_plus_u;
        lambda * kron(I_np,I_T(t,:)) * w_err_minus_u;
        kron(I_np,I_T(t,:)) * w_err_plus_u;
        - kron(I_np,I_T(t,:)) * w_err_minus_u;
        reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_plus_u );
        - reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_minus_u );
        - reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_plus_u );
        reshape(Fp',[],1) .* kron( ones(M,1),kron(I_np,I_T(t,:))*w_err_minus_u );
        - kron( I_np,I_T(t,:) ) * w_err_plus_u;
        kron( I_np,I_T(t,:) ) * w_err_minus_u;
        kron( I_np,I_T(t,:) ) * w_err_plus_u;
        - kron( I_np,I_T(t,:) ) * w_err_minus_u;
        - kron( I_ng,I_T(t,:) ) * xl;
        kron( I_ng,I_T(t,:) ) * xu;
        kron( I_np,I_T(t,:) ) * (w_forecast_vec + w_err_data_vec{j});
        kron( I_nl_shed,I_T(t,:) ) * d_shed_limit;   
        - Fmin - Fl * kron(I_nl,I_T(t,:)) * d + Fp * kron(I_np,I_T(t,:)) * (w_forecast_vec + w_err_data_vec{j});
        Fmax + Fl * kron(I_nl,I_T(t,:)) * d - Fp * kron(I_np,I_T(t,:)) * (w_forecast_vec + w_err_data_vec{j});
        kron( ones(1,nl),I_T(t,:) ) * d - kron( ones(1,np),I_T(t,:) ) * (w_forecast_vec + w_err_data_vec{j});
        - kron( ones(1,nl),I_T(t,:) ) * d + kron( ones(1,np),I_T(t,:) ) * (w_forecast_vec + w_err_data_vec{j});
        ];

    [sol_sub,fval_sub] = cplexmilp(f_sub,Ain_sub,bin_sub,[],[],[],[],[],lb_sub,ub_sub,ctype_sub);
    
    sigma_plus = sigma_plus + kron(sol_sub(1:np),I_T(:,t));
    sigma_minus = sigma_minus + kron(sol_sub(np + 1:2*np),I_T(:,t));

    UB = UB - fval_sub;

end