clear

is = 1;
fname = sprintf('sol_Proposed_%d.mat',is);
load(fname)

tic

common_matrix

exa_DRO_master_matrix
exa_RO_feas_matrix
exa_RO_sub_matrix
n_RO = 3*ng*T + 2*ng*T + 1 + ( ng*T + np*T + nl_shed*T );
Ain = [
    C0 zeros(size(C0,1),n_RO - 3*ng*T);
    C11 C12 zeros(size(C11,1),n_RO - 5*ng*T);
    zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),1) [ C22 zeros(size(C22,1),np*T + nl_shed*T) ] ;
    zeros(size(C61,1),5*ng*T+1) [ C61 C62 C63 ];
    zeros(1,3*ng*T + 2*ng*T) -1 kron(Cg',ones(1,T)) Cwc' Cds';
    ];
bin = [ c0; c1; c2; c6 + C64 * zeros(np*T,1); zeros(1,1) ];
Aeq = [ zeros(size(C81,1),5*ng*T + 1) C81 C82 C83 ];
beq = c8 + C84 * zeros(np*T,1);
f = [
    kron(Cu,ones(T,1));
    kron(Csu,ones(T,1));
    kron(Csd,ones(T,1));
    zeros(2*ng*T,1);
    1;
    zeros(n_RO - 5*ng*T - 1,1)
    ];
lb = zeros(n_RO,1);
ub = [ ones(3*ng*T,1); inf*ones(2*ng*T+1,1); inf*ones(ng*T,1); zeros(np*T,1); d_shed_limit ];
ctype = [ repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 1 + ng*T + np*T + nl_shed*T) ];

err_RO = 1;
while err_RO > 5e-3

    [sol,est_RO] = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
    
    uo_RO = sol(1 : ng*T);
    uu_RO = sol(ng*T + 1 : 2*ng*T);
    ud_RO = sol(2*ng*T + 1 : 3*ng*T);
    xu_RO = sol(3*ng*T + 1 : 4*ng*T);
    xl_RO = sol(4*ng*T + 1 : 5*ng*T);
    cost_ED_RO = sol(5*ng*T + 1);
    UCcost_RO = est_RO - cost_ED_RO;
    xu = xu_RO;
    xl = xl_RO;
    exa_RO_feas_problem
    if imbalance < 1e-6
        exa_RO_sub_problem
        w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma ;
        err_RO = (UB + UCcost_RO - est_RO)/est_RO;
        if err_RO > 5e-3
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(1,5*ng*T) -1 zeros(1, size(Ain,2) - 5*ng*T - 1) kron(Cg',ones(1,T)) Cwc' Cds';
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) [C61 C62 C63];
                ];
            bin = [
                bin;
                0;
                c2;
                c6 + C64 * (w_forecast_vec + w_err_wc);
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T+np*T+nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) [C81 C82 C83]
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
            n_RO = n_RO + ng*T + np*T + nl_shed*T;
        end
    else
        w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
        Ain = [
            Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
            zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
            zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
            ];
        bin = [
            bin;
            c2;
            c6 + C64 * (w_forecast_vec + w_err_wc)
            ];
        Aeq = [
            Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
            zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
            ];
        beq = [
            beq;
            c8 + C84 * (w_forecast_vec + w_err_wc)
            ];
        f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
        lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
        ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
        ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
        n_RO = n_RO + (ng*T + np*T + nl_shed*T);
    end
end
time_RO = toc;

fname = sprintf('sol_R.mat');
save(fname)
