clear

for is = 1 : 50
    
    fname = sprintf('sol_Proposed_%d.mat',is);
    load(fname)
    
    tic    
    common_matrix
    alpha_CDF = 0.01;
    c1_CDF = - 2.75 - 1.04 * log(alpha_CDF);
    c2_CDF = 4.76 - 1.2 * alpha_CDF;
    c3_CDF = 1.15 - 2.39 * alpha_CDF;
    c4_CDF = - 3.96 + 1.72 * alpha_CDF^0.171;
    alpha_tilde_CDF = exp(-c1_CDF-c2_CDF*sqrt(log(log(J)))-c3_CDF*log(J)^c4_CDF);

    for j = 1 : J
        pk_l(j,1) = icdf('beta',alpha_tilde_CDF/2,j,J+1-j);
        pk_u(j,1) = icdf('beta',1-alpha_tilde_CDF/2,j,J+1-j);
    end

    w_err_sum_data_CDF = cell(T,1);
    for t = 1 : T
        w_err_sum_data_CDF{t} = zeros(J,1);
        for j = 1 : J
            w_err_sum_data_CDF{t}(j) = sum(w_err_data{j}(t,:));
        end
        w_err_sum_data_CDF{t} = sort(w_err_sum_data_CDF{t});
    end
    
    w_err_sum_u_CDF = zeros(T,1);
    w_err_sum_l_CDF = zeros(T,1);
    delta_CDF = zeros(T,1);
    for t = 1 : T
        dum = [w_err_sum_data_CDF{t}; 0] - [0; w_err_sum_data_CDF{t}];
        dum(1) = [];
        dum(end) = [];
        delta_CDF(t) = max(max(dum,-dum));
        w_err_sum_u_CDF(t) = min( sum(cap) - sum(w_forecast(t,:)) , w_err_sum_data_CDF{t}(end) + delta_CDF(t)/2 );
        w_err_sum_l_CDF(t) = max( -sum(w_forecast(t,:)) , w_err_sum_data_CDF{t}(1) - delta_CDF(t)/2 );
    end
    
    C_plus_CDF = zeros(T,1);
    for t = 1 : T
        C_plus_CDF(t) = 0;
        for j = 1 : J - 1
            C_plus_CDF(t) = C_plus_CDF(t) +  ( w_err_sum_data_CDF{t}(j) - w_err_sum_data_CDF{t}(j+1) ) * pk_l(j);
        end
        C_plus_CDF(t) = C_plus_CDF(t) + ( w_err_sum_data_CDF{t}(J) - w_err_sum_u_CDF(t) ) * pk_l(J) + w_err_sum_u_CDF(t);
    end
    C_minus_CDF = zeros(T,1);
    for t = 1 : T
        C_minus_CDF(t) = ( w_err_sum_l_CDF(t) - w_err_sum_data_CDF{t}(j) ) * pk_u(1);
        for j = 2 : J
            C_minus_CDF(t) = C_minus_CDF(t) + ( w_err_sum_data_CDF{t}(j-1) - w_err_sum_data_CDF{t}(j) ) * pk_u(j);
        end
        C_minus_CDF(t) = C_minus_CDF(t) + w_err_sum_data_CDF{t}(J);
    end

    w_err_vec_l_CDF = zeros(np*T,1);
    delta_CDF2 = zeros(np,T);
    dum = w_err_data_vec{1};
    for j = 2 : J
        dum = [ dum w_err_data_vec{j} ];
    end
    dum = sort(dum,2);
    for t = 1 : T
        for ip = 1 : np
            dum2 = [dum((ip-1)*T+t,:)'; 0] - [0; dum((ip-1)*T+t,:)'];
            dum2(1) = [];
            dum2(end) = [];
            delta_CDF2(ip,t) = max(max(dum2,-dum2));
            w_err_vec_l_CDF((ip-1)*T+t) = max( -w_forecast_vec((ip-1)*T+t), dum((ip-1)*T+t,1) - delta_CDF2(ip,t)/2);
        end
    end
    
    delta_CDF3 = zeros(M,T);
    h_lt_vec_u_CDF = zeros(M*T,1);
    h_lt_vec_l_CDF = zeros(M*T,1);
    dum = kron(Fp,I_T) * w_err_data_vec{1};
    for j = 2 : J
        dum = [ dum kron(Fp,I_T) * w_err_data_vec{j} ];
    end
    dum = sort(dum,2);
    for t = 1 : T
        for l = 1 : M
            dum2 = [dum((l-1)*T+t,:)';0] - [0; dum((l-1)*T+t,:)'];
            dum2(1) = [];
            dum2(end) = [];
            delta_CDF3(l,t) = max(max(dum2,-dum2));
            
            [~,dum3] = cplexlp(-Fp(l,:)',[],[],[],[],-w_forecast(t,:)',cap - w_forecast(t,:)');
            h_lt_vec_u_CDF((l-1)*T+t) = min( -dum3, dum((l-1)*T+t,end) + delta_CDF3(l,t)/2 );
            [~,dum3] = cplexlp(Fp(l,:)',[],[],[],[],-w_forecast(t,:)',cap - w_forecast(t,:)');
            h_lt_vec_l_CDF((l-1)*T+t) = max( dum3, dum((l-1)*T+t,1) - delta_CDF3(l,t)/2 );            
        end
    end
        
    n_CDF = 3*ng*T + 2*ng*T + (ng*T + np*T + nl_shed*T) + (ng*T + np*T + nl_shed*T) + T;
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T,1);
        zeros(ng*T + np*T + nl_shed*T,1);
        kron(Cg,ones(T,1));
        Cwc;
        Cds;
        ones(T,1);
        ];
    Ain = [
        C0 zeros(size(C0,1),n_CDF - 3*ng*T);
        C11 C12 zeros(size(C11,1),n_CDF - 5*ng*T);
        zeros(ng*T,3*ng*T) -eye(ng*T) zeros(ng*T) kron(eye(ng),diag(w_err_sum_u_CDF)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,T);
        zeros(ng*T,3*ng*T) -eye(ng*T) zeros(ng*T) kron(eye(ng),diag(w_err_sum_l_CDF)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,T);
        zeros(ng*T,3*ng*T) zeros(ng*T) eye(ng*T) -kron(eye(ng),diag(w_err_sum_u_CDF)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) -eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,T);
        zeros(ng*T,3*ng*T) zeros(ng*T) eye(ng*T) -kron(eye(ng),diag(w_err_sum_l_CDF)) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) -eye(ng*T) zeros(ng*T,np*T) zeros(ng*T,nl_shed*T) zeros(ng*T,T);
        zeros(np*T,3*ng*T) zeros(np*T,2*ng*T) zeros(np*T,ng*T) -kron(eye(np),diag(w_err_sum_u_CDF)) zeros(np*T,nl_shed*T) zeros(np*T,ng*T) -eye(np*T) zeros(np*T,nl_shed*T) zeros(np*T,T);
        zeros(np*T,3*ng*T) zeros(np*T,2*ng*T) zeros(np*T,ng*T) -kron(eye(np),diag(w_err_sum_l_CDF)) zeros(np*T,nl_shed*T) zeros(np*T,ng*T) -eye(np*T) zeros(np*T,nl_shed*T) zeros(np*T,T);
        zeros(np*T,3*ng*T) zeros(np*T,2*ng*T) zeros(np*T,ng*T) kron(eye(np),diag(w_err_sum_u_CDF)) zeros(np*T,nl_shed*T) zeros(np*T,ng*T) eye(np*T) zeros(np*T,nl_shed*T) zeros(np*T,T);
        zeros(np*T,3*ng*T) zeros(np*T,2*ng*T) zeros(np*T,ng*T) kron(eye(np),diag(w_err_sum_l_CDF)) zeros(np*T,nl_shed*T) zeros(np*T,ng*T) eye(np*T) zeros(np*T,nl_shed*T) zeros(np*T,T);
        zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) -kron(eye(nl_shed),diag(w_err_sum_u_CDF)) zeros(nl_shed*T,ng*T+np*T) -eye(nl_shed*T) zeros(nl_shed*T,T);
        zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) -kron(eye(nl_shed),diag(w_err_sum_l_CDF)) zeros(nl_shed*T,ng*T+np*T) -eye(nl_shed*T) zeros(nl_shed*T,T);
        zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) kron(eye(nl_shed),diag(w_err_sum_u_CDF)) zeros(nl_shed*T,ng*T+np*T) eye(nl_shed*T) zeros(nl_shed*T,T);
        zeros(nl_shed*T,3*ng*T) zeros(nl_shed*T,2*ng*T) zeros(nl_shed*T,ng*T+np*T) kron(eye(nl_shed),diag(w_err_sum_l_CDF)) zeros(nl_shed*T,ng*T+np*T) eye(nl_shed*T) zeros(nl_shed*T,T);        
        zeros(M*T,5*ng*T) kron(Fg,diag(w_err_sum_u_CDF)) -kron(Fp,diag(w_err_sum_u_CDF)) kron(Fl_shed,diag(w_err_sum_u_CDF)) kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T) zeros(M*T,T);
        zeros(M*T,5*ng*T) kron(Fg,diag(w_err_sum_l_CDF)) -kron(Fp,diag(w_err_sum_l_CDF)) kron(Fl_shed,diag(w_err_sum_l_CDF)) kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T) zeros(M*T,T);
        zeros(M*T,5*ng*T) -kron(Fg,diag(w_err_sum_u_CDF)) kron(Fp,diag(w_err_sum_u_CDF)) -kron(Fl_shed,diag(w_err_sum_u_CDF)) -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T) zeros(M*T,T);
        zeros(M*T,5*ng*T) -kron(Fg,diag(w_err_sum_l_CDF)) kron(Fp,diag(w_err_sum_l_CDF)) -kron(Fl_shed,diag(w_err_sum_l_CDF)) -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T) zeros(M*T,T);
        zeros(T,5*ng*T) kron(Cg',diag(C_plus_CDF)) kron(ones(1,np),diag(C_plus_CDF))*diag(Cwc) kron(ones(1,nl_shed),diag(C_plus_CDF))*diag(Cds) zeros(T,ng*T + np*T + nl_shed*T) -eye(T);
        zeros(T,5*ng*T) kron(Cg',diag(C_minus_CDF)) kron(ones(1,np),diag(C_minus_CDF))*diag(Cwc) kron(ones(1,nl_shed),diag(C_minus_CDF))*diag(Cds) zeros(T,ng*T + np*T + nl_shed*T) -eye(T);
        ];
    bin = [
        a0;
        c1;
        zeros(4*ng*T,1);
        zeros(2*np*T,1);
        w_forecast_vec + w_err_vec_l_CDF;
        w_forecast_vec + w_err_vec_l_CDF;
        zeros(2*nl_shed*T,1);
        kron(ones(2,1),d_shed_limit);
        kron(Fmax,ones(T,1)) - kron(Fp,I_T) * w_forecast_vec + kron(Fl,I_T) * d - h_lt_vec_u_CDF;
        kron(Fmax,ones(T,1)) - kron(Fp,I_T) * w_forecast_vec + kron(Fl,I_T) * d - h_lt_vec_u_CDF;
        - kron(Fmin,ones(T,1)) + kron(Fp,I_T) * w_forecast_vec - kron(Fl,I_T) * d + h_lt_vec_l_CDF;
        - kron(Fmin,ones(T,1)) + kron(Fp,I_T) * w_forecast_vec - kron(Fl,I_T) * d + h_lt_vec_l_CDF;
        zeros(2*T,1);
        ];
    Aeq = [
        zeros(T,5*ng*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T)) zeros(T,ng*T+np*T+nl_shed*T) zeros(T);
        zeros(T,5*ng*T + ng*T + np*T + nl_shed*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T)) zeros(T)
        ];
    beq = [
        -ones(T,1);
        d_sum - w_forecast_sum
        ];
    lb = [zeros(3*ng*T,1); zeros(2*ng*T,1); -inf*ones(2*(ng*T+np*T+nl_shed*T),1); zeros(T,1)];
    ub = [ones(3*ng*T,1); inf*ones(2*ng*T + 2*(ng*T+np*T+nl_shed*T),1); inf*ones(T,1)];
    ctype = [repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 2*(ng*T+np*T+nl_shed*T) + T)];

    imbalance = 1;
    while imbalance > 1e-6

        sol = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
        uo_CDF = sol(1 : ng*T);
        uu_CDF = sol(ng*T+1 : 2*ng*T);
        ud_CDF = sol(2*ng*T + 1 : 3*ng*T);
        xu_CDF = sol(3*ng*T + 1 : 4*ng*T);
        xl_CDF = sol(4*ng*T + 1 : 5*ng*T);
        aff_g_1_CDF = sol(5*ng*T+1 : 6*ng*T);
        aff_g_1_res_CDF = reshape(aff_g_1_CDF,T,ng)';
        aff_wc_1_CDF = sol(6*ng*T + 1 : 6*ng*T + np*T);
        aff_wc_1_res_CDF = reshape(aff_wc_1_CDF,T,np)';
        aff_ds_1_CDF = sol(6*ng*T+np*T+1 : 6*ng*T+np*T+nl_shed*T);
        aff_ds_1_res_CDF = reshape(aff_ds_1_CDF,T,nl_shed)';
        aff_g_0_CDF = sol(6*ng*T+np*T+nl_shed*T+1 : 7*ng*T+np*T+nl_shed*T);
        aff_g_0_res_CDF = reshape(aff_g_0_CDF,T,ng)';
        aff_wc_0_CDF = sol(7*ng*T+np*T+nl_shed*T+1: 7*ng*T+2*np*T+nl_shed*T);
        aff_wc_0_res_CDF = reshape(aff_wc_0_CDF,T,np)';
        aff_ds_0_CDF = sol(7*ng*T+2*np*T+nl_shed*T+1 : 7*ng*T+2*np*T+2*nl_shed*T);    
        aff_ds_0_res_CDF = reshape(aff_ds_0_CDF,T,nl_shed)';

        exa_DRO_master_matrix
        exa_RO_feas_matrix
        xu = xu_CDF;
        xl = xl_CDF;
        exa_RO_feas_problem
        if imbalance > 1e-6
            dum_w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                ];
            bin = [
                bin;
                c2;
                c6 + C64 * (w_forecast_vec + dum_w_err_wc)
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + dum_w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + dum_w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
            n_CDF = n_CDF + (ng*T + np*T + nl_shed*T);
        end
    end
    time_CDF = toc;
    
    fname = sprintf('sol_C_%d.mat',is);
    save(fname)

end
