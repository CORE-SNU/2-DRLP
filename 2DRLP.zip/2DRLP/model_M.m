clear

for is = 1 : 50

    fname = sprintf('sol_Proposed_%d.mat',is);
    load(fname)

    tic
    common_matrix
    I_ngT = eye(ng*T);
    I_npT = eye(np*T);
    I_nlshedT = eye(nl_shed*T);
    [r, res] = mosekopt('symbcon');
    
    common_matrix
    feascheckindex = 0;
    mu_mm = zeros(np*T,1);
    for j = 1 : J
        mu_mm = mu_mm + 1/J * w_err_data_vec{j};
    end
    sigma_mm = zeros(np*T,1);
    for ip = 1 : np
        for t = 1 : T
            dum = 0;
            for j = 1 : J
                dum = dum + ( w_err_data_vec{j}((ip-1)*T + t)  - mu_mm( (ip-1)*T + t ) )^2;
            end
            sigma_mm((ip-1)*T + t) = 1/J * dum;
        end
    end
    v_u_mm = zeros(np*T,1);
    for ip = 1 : np
        for t = 1 : T
            dum = 0;
            for j = 1 : J
                dum = [ dum; ( w_err_data_vec{j}( (ip-1)*T + t ) - mu_mm( (ip-1)*T + t ) )^2 ];
            end
            dum(1) = [];
            v_u_mm( (ip-1)*T + t ) = max(dum);
        end
    end
   
    n_mm = 5*ng*T + ...
        3 * ( ng*T + np*T + nl_shed*T ) + ...
        1 + ...
        np*T + ... 
        np*T + ... 
        np*T + ... 
        np*T + ... 
        np*T + ... 
        np*T + ... 
        np*T + ... 
        np*T; 
    n_mm_all = 5*ng*T + 3*T*(ng+np+nl_shed) + 1 + 8*np*T + 6 * np * (2*ng*T + 2*np*T + 2*nl_shed*T + 2*M*T);
    
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T + 3*T*(ng + np + nl_shed),1);
        1;
        mu_mm;
        sigma_mm;
        zeros( 6*np*T , 1 );
        ];

    Ain = [
        C0 zeros(size(C0,1),n_mm - 3*ng*T);
        C11 C12 zeros(size(C11,1),n_mm - 5*ng*T);
        -f';
        zeros(1,5*ng*T) zeros(1,ng*T+np*T+nl_shed*T) Cg_ext' zeros(1,ng*T+np*T+nl_shed*T) -1 zeros( 1, 2*np*T ) w_err_l_vec' w_err_u_vec' -2*mu_mm' -ones(1,np*T) ones(1,np*T) v_u_mm';
        ];
    
    bin = [
        a0;
        c1;
        0;
        0;
        ];

    dum = [ kron(ones(ng,1),kron(ones(1,np),I_T))' kron(ones(np,1),kron(ones(1,np),I_T))' kron(ones(nl_shed,1),kron(ones(1,np),I_T))' ] * diag(Cg_ext);
    Aeq = [
        zeros(T,5*ng*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T)) zeros(T,ng*T+np*T+nl_shed*T) zeros(T,ng*T+np*T+nl_shed*T) zeros(T,1+8*np*T);
        zeros(T,5*ng*T + ng*T + np*T + nl_shed*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T)) zeros(T,ng*T+np*T+nl_shed*T) zeros(T,1+8*np*T);
        zeros(T,5*ng*T + 2*ng*T + 2*np*T + 2*nl_shed*T) kron(ones(1,ng),eye(T)) -kron(ones(1,np),eye(T)) kron(ones(1,nl_shed),eye(T))  zeros(T,1+8*np*T);       
        zeros(np*T,5*ng*T) -dum zeros(np*T,2*T*(ng+np+nl_shed)) zeros(np*T,1) eye(np*T) zeros(np*T) eye(np*T) eye(np*T) -2*eye(np*T) zeros(np*T,3*np*T);
        zeros(np*T,5*ng*T) zeros(np*T,2*T*(ng+np+nl_shed)) -dum zeros(np*T,1+np*T) eye(np*T) zeros(np*T,3*np*T) -eye(np*T) -eye(np*T) eye(np*T);    
        ];
    
    beq = [
        -ones(T,1);
        d_sum - w_forecast_sum;
        zeros(T,1);
        zeros(2*np*T,1);
        ];
    
    lb = [
        zeros(5*ng*T,1); 
        -inf*ones(3*(ng*T+np*T+nl_shed*T),1);
        -inf;
        -inf*ones(np*T,1);
        zeros(np*T,1);
        -inf*ones(np*T,1);
        zeros(np*T,1);
        -inf*ones(2*np*T,1);
        zeros(2*np*T,1);
        ];
    ub = [ 
        ones(3*ng*T,1);
        inf*ones(2*ng*T,1);
        inf*ones(3*(ng*T+np*T+nl_shed*T),1);
        inf;
        inf*ones(np*T,1);
        inf*ones(np*T,1);
        zeros(np*T,1);
        inf*ones(np*T,1);
        inf*ones(3*np*T,1);
        inf*ones(np*T,1);
        ];
    
    n_SOC_all = np*T + np * (2*ng*T + 2*np*T + 2*nl_shed*T + 2*M*T);
    n_SOC = 0;
    prob.cones.type = 0;
    prob.cones.sub = 0;
    prob.cones.subptr = 0;
    
    for dumindex = 1 : np*T
        t = mod(dumindex,T);
        if t == 0
            t = T;
        end
        ip = (dumindex-t)/T + 1;
        n_SOC = n_SOC + 1;
        etaindex = 5*ng*T + 3*T*(ng+np+nl_shed) + 1 + 4*np*T + (ip-1)*T + t;
        kappaindex = 5*ng*T + 3*T*(ng+np+nl_shed) + 1 + 4*np*T + np*T + (ip-1)*T + t;
        piindex = 5*ng*T + 3*T*(ng+np+nl_shed) + 1 + 4*np*T + 2*np*T + (ip-1)*T + t;

        prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
        prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
        if ip == 1 && t == 1
            prob.cones.type(1) = [];
            prob.cones.sub(1) = [];
        end
        prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
        if ip == 1 && t == 1
            prob.cones.subptr(1) = [];
        end
    end
    
    G_mm = [ eye(ng*T) zeros(ng*T,np*T+nl_shed*T) ];
    h_mm = zeros(ng*T,1);
    E_mm = [ zeros(ng*T,3*ng*T) -eye(ng*T) zeros(ng*T) ];
    f = [ f; zeros(6*np*ng*T,1) ];
    bin = [ bin; h_mm ];
    beq = [ beq; zeros(2*np*ng*T,1) ];
    lb = [ lb; kron(ones(ng*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(ng*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];
    
    dum = 0;
    for t = 1 : T
        dum = blkdiag(dum,...
            [ (kron(eye(np),I_T(t,:))*w_err_l_vec)' (kron(eye(np),I_T(t,:)) * w_err_u_vec)' -2*( kron(eye(np),I_T(t,:)) * mu_mm)' -ones(1,np) ones(1,np) ( kron(eye(np),I_T(t,:)) * v_u_mm)' ]);
    end
    dum(1,:) = [];
    dum(:,1) = [];
    Ain = [
        Ain zeros(size(Ain,1),6*np*ng*T);
        E_mm zeros(ng*T,ng*T+np*T+nl_shed*T) G_mm zeros(ng*T,ng*T+np*T+nl_shed*T + 1 + 8*np*T) kron(eye(ng),dum)
        ];
    
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*ng*T);
        zeros(ng*T*np,5*ng*T) -kron(I_ngT,ones(np,1)) zeros(ng*T*np,size(Aeq,2) - 5*ng*T - ng*T) kron(eye(ng*T),[ eye(np) eye(np) -2*eye(np) zeros(np,3*np) ]);
        zeros(ng*T*np,5*ng*T) zeros(np*ng*T,2*T*(ng+np+nl_shed)) -kron(I_ngT,ones(np,1)) zeros(np*ng*T,np*T+nl_shed*T) zeros(np*ng*T,size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(ng*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];
    
    for ig = 1 : ng
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip = 1 : np                
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip;
                kappaindex = n_mm - 6*np + 3*np + ip;
                piindex = n_mm - 6*np + 4*np + ip;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end

    G_mm = [ -eye(ng*T) zeros(ng*T,np*T+nl_shed*T) ];
    h_mm = zeros(ng*T,1);
    E_mm = [ zeros(ng*T,3*ng*T) zeros(ng*T) eye(ng*T) ];
    f = [ f; zeros(6*np*ng*T,1) ];
    bin = [ bin; h_mm ];
    beq = [ beq; zeros(2*np*ng*T,1) ];
    lb = [ lb; kron(ones(ng*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(ng*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];
    
    Ain = [
        Ain zeros(size(Ain,1),6*np*ng*T);
        E_mm zeros(ng*T,ng*T+np*T+nl_shed*T) G_mm zeros(ng*T,ng*T+np*T+nl_shed*T) zeros(ng*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(ng),dum)
        ];
    
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*ng*T);
        zeros(ng*T*np,5*ng*T) kron(I_ngT,ones(np,1)) zeros(ng*T*np,size(Aeq,2) - 5*ng*T - ng*T) kron(eye(ng*T),[ eye(np) eye(np) -2*eye(np) zeros(np,3*np) ]);
        zeros(ng*T*np,5*ng*T) zeros(np*ng*T,2*T*(ng+np+nl_shed)) kron(I_ngT,ones(np,1)) zeros(np*ng*T,np*T+nl_shed*T) zeros(np*ng*T,size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(ng*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];

    for ig = 1 : ng
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip = 1 : np
            n_SOC = n_SOC + 1;
            etaindex = n_mm - 6*np + 2*np + ip;
            kappaindex = n_mm - 6*np + 3*np + ip;
            piindex = n_mm - 6*np + 4*np + ip;
            prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
            prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
            prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end
    
    G_mm = [ zeros(np*T,ng*T) -eye(np*T) zeros(np*T,nl_shed*T) ];
    h_mm = zeros(np*T,1);
    E_mm = zeros(np*T,5*ng*T);
    f = [ f; zeros(6*np*np*T,1) ];
    bin = [ bin; h_mm ];
    beq = [ beq; zeros(2*np*np*T,1) ];
    lb = [ lb; kron(ones(np*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(np*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];

    Ain = [
        Ain zeros(size(Ain,1),6*np*np*T);
        E_mm zeros(np*T,ng*T+np*T+nl_shed*T) G_mm zeros(np*T,ng*T+np*T+nl_shed*T) zeros(np*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(np),dum)
        ];
    
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*np*T);
        zeros(np*np*T,5*ng*T) zeros(np*np*T,ng*T) kron(I_npT,ones(np,1)) zeros(np*np*T, size(Aeq,2) - 5*ng*T - ng*T -np*T) kron(eye(np*T),[eye(np) eye(np) -2*eye(np) zeros(np,3*np)]);
        zeros(np*np*T,5*ng*T) zeros(np*np*T,2*T*(ng+np+nl_shed)) zeros(np*np*T,ng*T) kron(I_npT,ones(np,1)) zeros(np*np*T,nl_shed*T) zeros(np*np*T, size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(np*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];

    for ip = 1 : np
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip_prime = 1 : np
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip_prime;
                kappaindex = n_mm - 6*np + 3*np + ip_prime;
                piindex = n_mm - 6*np + 4*np + ip_prime;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end

    G_mm = [ zeros(np*T,ng*T) eye(np*T) zeros(np*T,nl_shed*T) ];
    h_mm = w_forecast_vec;
    E_mm = zeros(np*T,5*ng*T);
    f = [ f; zeros(6*np*np*T,1) ];
    lb = [ lb; kron(ones(np*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(np*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];
    bin = [bin; h_mm];

    Ain = [
        Ain zeros(size(Ain,1),6*np*np*T);
        E_mm zeros(np*T,ng*T+np*T+nl_shed*T) G_mm zeros(np*T,ng*T+np*T+nl_shed*T) zeros(np*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(np),dum)
        ];
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*np*T);
        zeros(np*np*T,5*ng*T) zeros(np*np*T,ng*T) -kron(I_npT,ones(np,1)) zeros(np*np*T,nl_shed*T) zeros(np*np*T,2*T*(ng+np+nl_shed)) zeros(np*np*T, size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(np*T),[eye(np) eye(np) -2*eye(np) zeros(np,3*np)]);
        zeros(np*np*T,5*ng*T) zeros(np*np*T,2*T*(ng+np+nl_shed)) zeros(np*np*T,ng*T) -kron(I_npT,ones(np,1)) zeros(np*np*T,nl_shed*T) zeros(np*np*T,size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(np*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)]);
        ];
    dumdum = 0;
    for ip_prime = 1 : np
        dumdum = [ dumdum; kron(ones(T,1),-I_np(:,ip_prime)) ];
    end
    dumdum(1) = [];
    beq = [ beq; dumdum; zeros(np*np*T,1) ];
    
    for ip = 1 : np
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip_prime = 1 : np
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip_prime;
                kappaindex = n_mm - 6*np + 3*np + ip_prime;
                piindex = n_mm - 6*np + 4*np + ip_prime;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end
    
    G_mm = [ zeros(nl_shed*T,ng*T + np*T) -eye(nl_shed*T) ];
    h_mm = zeros(nl_shed*T,1);
    E_mm = zeros(nl_shed*T,5*ng*T);
    f = [ f; zeros(6*np*nl_shed*T,1) ];
    bin = [ bin; h_mm ];
    beq = [ beq; zeros(2*np*nl_shed*T,1) ];
    lb = [ lb; kron(ones(nl_shed*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(nl_shed*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];

    Ain = [
        Ain zeros(size(Ain,1),6*np*nl_shed*T);
        E_mm zeros(nl_shed*T,ng*T+np*T+nl_shed*T) G_mm zeros(nl_shed*T,ng*T+np*T+nl_shed*T) zeros(nl_shed*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(nl_shed),dum)
        ];
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*nl_shed*T);
        zeros(nl_shed*np*T,5*ng*T) zeros(np*nl_shed*T,ng*T+np*T) kron(I_nlshedT,ones(np,1)) zeros(np*nl_shed*T, size(Aeq,2) - 5*ng*T - ng*T -np*T -nl_shed*T) kron(eye(nl_shed*T),[eye(np) eye(np) -2*eye(np) zeros(np,3*np)]);
        zeros(nl_shed*np*T,5*ng*T) zeros(np*nl_shed*T,2*T*(ng+np+nl_shed) + ng*T + np*T) kron(I_nlshedT,ones(np,1)) zeros(np*nl_shed*T, size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(nl_shed*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];

    for il = 1 : nl_shed
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip = 1 : np
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip;
                kappaindex = n_mm - 6*np + 3*np + ip;
                piindex = n_mm - 6*np + 4*np + ip;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end
    
    G_mm = [ zeros(nl_shed*T,ng*T + np*T) eye(nl_shed*T) ];
    h_mm = d_shed_limit;
    E_mm = zeros(nl_shed*T,5*ng*T);
    f = [ f; zeros(6*np*nl_shed*T,1) ];
    beq = [ beq; zeros(2*np*nl_shed*T,1) ];
    lb = [ lb; kron(ones(nl_shed*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(nl_shed*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];
    bin = [bin; h_mm];
    Ain = [
        Ain zeros(size(Ain,1),6*np*nl_shed*T);
        E_mm zeros(nl_shed*T,ng*T+np*T+nl_shed*T) G_mm zeros(nl_shed*T,ng*T+np*T+nl_shed*T) zeros(nl_shed*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(nl_shed),dum)
        ];
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*nl_shed*T);
        zeros(np*nl_shed*T,5*ng*T) zeros(np*nl_shed*T,ng*T+np*T) -kron(I_nlshedT,ones(np,1)) zeros(np*nl_shed*T, size(Aeq,2) - 5*ng*T - ng*T -np*T -nl_shed*T) kron(eye(nl_shed*T),[eye(np) eye(np) -2*eye(np) zeros(np,3*np)]);
        zeros(np*nl_shed*T,5*ng*T) zeros(np*nl_shed*T,2*T*(ng+np+nl_shed) + ng*T + np*T) -kron(I_nlshedT,ones(np,1)) zeros(np*nl_shed*T, size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(nl_shed*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];
    
    for il = 1 : nl_shed
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip = 1 : np
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip;
                kappaindex = n_mm - 6*np + 3*np + ip;
                piindex = n_mm - 6*np + 4*np + ip;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end
    
    G_mm = - kron([ Fg -Fp Fl_shed ],I_T);
    h_mm = - kron(Fmin,ones(T,1)) - kron(Fl,I_T)*d + kron(Fp,I_T)*w_forecast_vec;
    E_mm = zeros(M*T,5*ng*T);
    M_mm = - Fp;
    f = [ f; zeros(6*np*M*T,1) ];
    lb = [ lb; kron(ones(M*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(M*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];
    Ain = [
        Ain zeros(size(Ain,1),6*np*M*T);
        E_mm zeros(M*T,ng*T+np*T+nl_shed*T) G_mm zeros(M*T,ng*T+np*T+nl_shed*T) zeros(M*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(M),dum)
        ];
    bin = [ bin; h_mm ];
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*M*T);
        zeros(np*M*T,5*ng*T) -kron(G_mm,ones(np,1)) zeros(np*M*T, size(Aeq,2) - 5*ng*T - ng*T -np*T -nl_shed*T) kron(eye(M*T),[eye(np) eye(np) -2*eye(np) zeros(np,3*np)]);
        zeros(np*M*T,5*ng*T) zeros(np*M*T,2*T*(ng+np+nl_shed)) -kron(G_mm,ones(np,1)) zeros(np*M*T, size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(M*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];
    dumdum = 0;
    for l = 1 : M
        dumdum = [ dumdum; kron(ones(T,1),M_mm(l,:)') ];
    end
    dumdum(1) = [];
    beq = [ beq; dumdum; zeros(np*M*T,1) ];

    for l = 1 : M
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip = 1 : np
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip;
                kappaindex = n_mm - 6*np + 3*np + ip;
                piindex = n_mm - 6*np + 4*np + ip;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end
    
    G_mm = kron([ Fg -Fp Fl_shed ],I_T);
    h_mm = kron(Fmax,ones(T,1)) + kron(Fl,I_T)*d - kron(Fp,I_T)*w_forecast_vec;
    E_mm = zeros(M*T,5*ng*T);
    M_mm = Fp;
    f = [ f; zeros(6*np*M*T,1) ];
    lb = [ lb; kron(ones(M*T,1),[ -inf*ones(np,1); zeros(np,1); -inf*ones(2*np,1); zeros(2*np,1) ]) ];
    ub = [ ub; kron(ones(M*T,1),[ zeros(np,1); inf*ones(np,1); inf*ones(2*np,1); inf*ones(2*np,1)]) ];
    Ain = [
        Ain zeros(size(Ain,1),6*np*M*T);
        E_mm zeros(M*T,ng*T+np*T+nl_shed*T) G_mm zeros(M*T,ng*T+np*T+nl_shed*T) zeros(M*T,size(Ain,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(M),dum)
        ];
    bin = [ bin; h_mm ];
    Aeq = [
        Aeq zeros(size(Aeq,1),6*np*M*T);
        zeros(np*M*T,5*ng*T) -kron(G_mm,ones(np,1)) zeros(np*M*T, size(Aeq,2) - 5*ng*T - ng*T -np*T -nl_shed*T) kron(eye(M*T),[eye(np) eye(np) -2*eye(np) zeros(np,3*np)]);
        zeros(np*M*T,5*ng*T) zeros(np*M*T,2*T*(ng+np+nl_shed)) -kron(G_mm,ones(np,1)) zeros(np*M*T, size(Aeq,2)-(5*ng*T+3*(ng*T+np*T+nl_shed*T))) kron(eye(M*T),[zeros(np,3*np) -eye(np) -eye(np) eye(np)])
        ];
    dumdum = 0;
    for l = 1 : M
        dumdum = [ dumdum; kron(ones(T,1),M_mm(l,:)') ];
    end
    dumdum(1) = [];
    beq = [ beq; dumdum; zeros(np*M*T,1) ];

    for l = 1 : M
        for t = 1 : T
            n_mm = n_mm + 6*np;
            for ip = 1 : np
                n_SOC = n_SOC + 1;
                etaindex = n_mm - 6*np + 2*np + ip;
                kappaindex = n_mm - 6*np + 3*np + ip;
                piindex = n_mm - 6*np + 4*np + ip;
                prob.cones.type = [ prob.cones.type res.symbcon.MSK_CT_QUAD ];
                prob.cones.sub = [ prob.cones.sub piindex etaindex kappaindex ];
                prob.cones.subptr = [ prob.cones.subptr size(prob.cones.sub,2)-2 ];
            end
        end
    end
    
    checkindex_mm = 1;
    while checkindex_mm > 0

        prob.c = f';
        prob.a = sparse([Ain; Aeq]);
        prob.buc = [bin' beq'];
        prob.blc = [-inf*ones(1,size(bin,1)) beq'];
        prob.blx = lb';
        prob.bux = ub';
        prob.ints.sub = 1:3*ng*T;

        [r, res] = mosekopt('minimize',prob);
        sol = res.sol.int.xx;
        uo_mm = sol(1 : ng*T);
        uu_mm = sol(ng*T + 1 : 2*ng*T);
        ud_mm = sol(2*ng*T + 1 : 3*ng*T);
        xu_mm = sol(3*ng*T + 1 : 4*ng*T);
        xl_mm = sol(4*ng*T + 1 : 5*ng*T);    

        exa_DRO_master_matrix
        exa_RO_feas_matrix
        xu = xu_mm;
        xl = xl_mm;
        exa_RO_feas_problem
        if imbalance < 1e-6
            checkindex_mm = 0;
        else
            feascheckindex = feascheckindex + 1;
            dum_w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                ];
            bin = [
                bin;
                c2;
                c6 + C64 * (w_forecast_vec + dum_w_err_wc)
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + dum_w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + dum_w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
            n_mm = n_mm + (ng*T + np*T + nl_shed*T);
        end
    end
    time_MM = toc;
    
    fname = sprintf('sol_M_%d.mat',is);
    save(fname)

end
